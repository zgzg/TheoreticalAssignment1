//����course��
public class course {
	String classId;
	String className;
	String classType;
	double credit;
	String teacher;
	String department;
	String type;
	String year;
	String semester;
	double score;
	
//����score��credit��ֵ
	public double getScore()
	{
		return score;
	}
	public double getCredit()
	{
		return credit;
	}
	//��ʼ��
	public course(String myclassId,
			String myclassName,
			String myclassType,
			double mycredit,
			String myteacher,
			String mydepartment,
			String mytype,
			String myyear,
			String mysemester,
			double myscore){
				this.classId = myclassId;
				this.className = myclassName;
				this.classType = myclassType;
				this.credit = mycredit;
				this.teacher = myteacher;
				this.department = mydepartment;
				this.type = mytype;
				this.year = myyear;
				this.semester = mysemester;
				this.score = myscore;
}
}
