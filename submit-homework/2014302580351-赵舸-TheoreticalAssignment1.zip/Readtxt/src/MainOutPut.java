import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Collections;

public class MainOutPut {
	
	@SuppressWarnings("unchecked")
	public static void processScoretable(File input){
	     ArrayList <course> inputList =new ArrayList<course>();
         //��ȡtxt�ļ�
	     try {
                String encoding="gbk";
                File display=new File("display.txt");
                //�ж��ļ��Ƿ����
                if(input.isFile() && input.exists()){ 
                	
                    InputStreamReader read = new InputStreamReader(new FileInputStream(input),encoding);
                    BufferedReader bufferedReader = new BufferedReader(read);
                    //���н�course��Ķ���д��inputlist����
                    String line = null;
                    while((line = bufferedReader.readLine()) != null){
                    	String [] coursearr = line.split("\\t");    
                    	inputList.add(new course(coursearr[0],coursearr[1],coursearr[2],Double.valueOf(coursearr[3]),coursearr[4],coursearr[5],coursearr[6],coursearr[7],coursearr[8],Double.valueOf(coursearr[9])));
                    
                    }
                    bufferedReader.close();
                    //���ɼ���С����
                    Collections.sort(inputList,new SortByScore());
                    //���Ź��������鰴��д����txt�ļ�
                    OutputStreamWriter writer=new OutputStreamWriter(new FileOutputStream(display),encoding);
                	BufferedWriter bW = new BufferedWriter(writer);
                	for(course i:inputList){
                		bW.write(i.classId+"\t"+i.className+"\t"+i.classType+"\t"+
					i.credit+"\t"+i.teacher +"\t"+i.department+"\t"+i.type+"\t"+i.year+"\t"+
						i.semester+"\t"+i.score+"\r\n");
                	}
					//д���Ȩƽ���ֺͼ�ȨGPA
                	bW.write("��Ȩƽ���֣� "+calculatorscore(inputList));
					bW.write("��ȨGPA: "+calculatorgpa(inputList));
                	bW.close();
        }else{
            System.out.println("�Ҳ���ָ�����ļ�");
        }
        } catch (IOException e) {
            System.out.println("��ȡ�ļ����ݳ���");
            e.printStackTrace();
        }
	}
	//�����Ȩƽ����
	public static double calculatorscore(ArrayList<course> al){
		double   averagescore;
		double   sumcredit = 0;
		double   sumscore = 0;
		for(course i:al){
			double credit = i.getCredit();
			double score = i.getScore();
			sumcredit = sumcredit + credit;
			sumscore = sumscore + score*credit;
		}
		averagescore = sumscore / sumcredit;
		return averagescore;
		
	}
	//�����Ȩƽ��GPA
	public static double calculatorgpa(ArrayList<course> al){
		double  sumcredit=0;
		double  sumgpa=0;
		double  averagegpa;
		for(course i:al)
		{  double  gpa = 0;
		   double score=i.getScore();
		   double credit=i.getCredit();
		   
		   if(score>=90&&score<=100){gpa = 4.0;}
		   if(score>=85&&score<=89){gpa = 3.7;}
		   if(score>=82&&score<=84){gpa = 3.3;}
		   if(score>=78&&score<=81){gpa = 3.0;}
		   if(score>=75&&score<=77){gpa = 2.7;}
		   if(score>=72&&score<=74){gpa = 2.3;}
		   if(score>=68&&score<=71){gpa = 2.0;}
		   if(score>=64&&score<=67){gpa = 1.5;}
		   if(score>=60&&score<=63){gpa = 1.0;}
		   if(score>=0&&score<=59){gpa = 0;}
		   
		  sumgpa=sumgpa+gpa*credit;
		  sumcredit=sumcredit+credit;
		  
		
		
		}
		
		averagegpa=sumgpa/sumcredit;
		
		return  averagegpa;
	}
	
	
	
	
	
	
	
	

}
