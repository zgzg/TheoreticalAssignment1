import java.util.Comparator;

public class SortByScore implements Comparator {

	@Override
    //�Ƚϴ�С
	public int compare(Object arg0, Object arg1) {
		
		course a1 = (course)arg0;
		course a2 = (course)arg1;
		if(a1.getScore()>a2.getScore())
		{
			return -1;
		}
		else if(a1.getScore()<a2.getScore())
		{
			return 1;
		}
		return 0;
	}

}
